import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import date

# chargement de données 
def charger_donnees(chemin):
    df = pd.read_csv(chemin)
    df.columns = df.columns.str.strip()  # Nettoie les noms de colonnes
    return df

# appel de la fonction
df = charger_donnees("data/BeansDataSet.csv")

# Liste des produits pour les graphiques
produits = ["Robusta", "Arabica", "Espresso", "Lungo", "Latte", "Cappuccino"]

# Titre de la sidebar
st.sidebar.title('Projet Beans & Pods')

# Filtres dynamiques disponibles dans tous les menus
st.sidebar.subheader("Filtres")
regions = st.sidebar.multiselect("Choisir la ou les régions", options=df["Region"].unique(), default=df["Region"].unique())
canaux = st.sidebar.multiselect("Choisir le ou les canaux", options=df["Channel"].unique(), default=df["Channel"].unique())
df_filtre = df[df["Region"].isin(regions) & df["Channel"].isin(canaux)]

# Menu principal
menu = st.sidebar.selectbox("Menu", ["Exploration", "Graphiques", "Corrélations", "Recommandations"])

# Section 1 : Exploration des données
if menu == "Exploration":
    st.title("Exploration des données")
    st.markdown("Voici les données du fichier BeansDataSet.csv :")

    # Affichage des données filtrées
    st.dataframe(df_filtre.head())

    # Statistiques simples
    st.subheader("Statistiques descriptives")
    st.write(df_filtre.describe())

# Section 2 : Graphiques
elif menu == "Graphiques":
    st.title("Visualisation des ventes")

    st.subheader("1. Répartition des ventes par canal")
    fig1, ax1 = plt.subplots()
    df_filtre["Channel"].value_counts().plot.pie(autopct='%1.1f%%', ax=ax1)
    ax1.set_ylabel("")
    st.pyplot(fig1)

    st.subheader("2. Moyenne des ventes par produit")
    fig2, ax2 = plt.subplots()
    df_filtre[produits].mean().sort_values().plot.bar(ax=ax2)
    ax2.set_ylabel("Ventes moyennes")
    st.pyplot(fig2)

    st.subheader("3. Ventes moyennes par région et produit")
    fig3, ax3 = plt.subplots(figsize=(10, 5))
    sns.barplot(data=pd.melt(df_filtre, id_vars=["Region"], value_vars=produits), x="Region", y="value", hue="variable", ax=ax3)
    ax3.set_ylabel("Ventes moyennes")
    st.pyplot(fig3)

# Section 3 : Corrélations
elif menu == "Corrélations":
    st.title("Analyse de corrélation")
    st.markdown("Voici la matrice de corrélation entre les types de produits :")
    corr = df_filtre[produits].corr()
    fig4, ax4 = plt.subplots()
    sns.heatmap(corr, annot=True, cmap="coolwarm", ax=ax4)
    ax4.set_title("Corrélation entre les produits")
    st.pyplot(fig4)

# Section 4 : Recommandations
elif menu == "Recommandations":
    st.title("Recommandations pour Beans & Pods")

    st.subheader("Analyse textuelle des données")
    st.markdown("""
    Après analyse des données, plusieurs observations se dégagent :

    - Le **canal Online** semble dominer en volume de ventes, notamment pour les gousses comme **Espresso** et **Latte**.
    - Les **régions South et Central** ont des volumes de ventes globalement plus élevés comparés au North.
    - Les produits **Arabica** et **Espresso** sont les plus vendus en moyenne, indiquant une préférence des consommateurs pour ces variétés.
    - En revanche, les ventes de **Lungo** et **Cappuccino** sont moins importantes, ce qui suggère une opportunité de promotion ciblée.
    - Il existe aussi une **corrélation notable** entre les ventes de certaines gousses (Espresso, Latte, Cappuccino), ce qui permettrait de proposer des packs groupés.
    """)

    st.subheader("Suggestions marketing")
    st.markdown("""
    - **Cibler les régions les plus fortes (ex: South)** pour augmenter les revenus.
    - **Améliorer la visibilité des produits peu vendus comme Lungo et Cappuccino.**
    - **Renforcer la présence sur le canal Online**, surtout pour les gousses populaires.
    - **Faire des promotions croisées** sur les produits corrélés comme Espresso et Latte.
    """)

    st.subheader("Nouvelles données à collecter")
    st.markdown("""
    - **Date des ventes** pour analyser les saisons et tendances.
    - **Prix par unité** pour identifier les produits les plus rentables.
    - **Type de client** (nouveau/fidèle) pour mieux cibler.
    - **Budget marketing dépensé** pour mesurer les performances.
    """)

# Crédit
st.markdown("---")
st.caption("Projet 1 - Institut Teccart - 420-IAA-TT - Hiver 2025 - Mustapha Benidir")
